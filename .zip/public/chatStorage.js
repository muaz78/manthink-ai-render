const STORAGE_KEY = "manthink_chats";

function loadChats() {
  return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
}

function saveChats(chats) {
  localStorage.setItem(
    STORAGE_KEY,
    JSON.stringify(chats)
  );
}

function createChat() {
  return {
    id: Date.now().toString(),
    title: "New Chat",
    createdAt: Date.now(),
    messages: []
  };
}